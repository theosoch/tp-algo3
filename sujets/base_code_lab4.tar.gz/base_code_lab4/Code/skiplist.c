#include <stdlib.h>
#include <assert.h>

#include "skiplist.h"
#include "rng.h"


SkipList skiplist_create(int nblevels) {
	(void)nblevels;
	return NULL;
}

void skiplist_delete(SkipList d) {
	(void)d;
}

SkipList skiplist_insert(SkipList d, int value) {
	(void)value;
	return d;
}
